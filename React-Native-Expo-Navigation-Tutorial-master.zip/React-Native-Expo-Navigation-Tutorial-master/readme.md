![React native and expo navigation tutorial](react-native-navigation.jpg)

# React native and expo navigation tutorial

This repository contains code of the video tutorial that you can find here: https://youtu.be/2QhxKJlMD4g 
